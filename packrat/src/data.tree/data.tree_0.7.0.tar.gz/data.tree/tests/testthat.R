library(testthat)

test_check("data.tree")
#devtools::test()